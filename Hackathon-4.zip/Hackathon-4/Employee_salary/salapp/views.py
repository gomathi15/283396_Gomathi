
from django.shortcuts import render
import random

def salary_form(request):
    return render(request, 'Employee_salary/empsal/salapp/templates/salapp/form.html')

def salary_result(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        gross = float(request.POST.get('gross_salary'))
        tax = float(request.POST.get('tax'))
        bonus = float(request.POST.get('bonus'))

        net_salary = gross - (tax / 100 * gross) + (bonus / 100 * gross)

        return render(request, 'Employee_salary/empsal/salapp/templates/salapp/result.html', {'name': name,'net_salary': round(net_salary, 2)})
    return render(request, 'salapp/form.html') 

def jumble_word(request):
    jumbled = ''
    word = ''
    if request.method == 'POST':
        word = request.POST.get('word', '')
        jumbled = ''.join(random.sample(word, len(word)))
    return render(request, 'Employee_salary/empsal/salapp/templates/salapp/jumble.html', {'word': word, 'jumbled': jumbled})
